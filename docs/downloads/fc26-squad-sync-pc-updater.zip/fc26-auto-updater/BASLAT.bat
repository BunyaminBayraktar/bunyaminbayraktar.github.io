@echo off
setlocal
cd /d "%~dp0"

rem Try the Windows Python Launcher first.
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if not errorlevel 1 goto run_py

rem Then try Python commands available in PATH.
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if not errorlevel 1 goto run_python
python3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
if not errorlevel 1 goto run_python3

rem Finally check the standard per-user install locations.
if exist "%LocalAppData%\Programs\Python\Python314\python.exe" goto run_314
if exist "%LocalAppData%\Programs\Python\Python313\python.exe" goto run_313
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" goto run_312
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" goto run_311
if exist "%LocalAppData%\Programs\Python\Python310\python.exe" goto run_310

echo Python 3.10 veya daha yenisi bulunamadi.
echo Kurulum: https://www.python.org/downloads/
echo Kurulum ekraninda "Add python.exe to PATH" secenegini isaretleyin.
pause
exit /b 1

:run_py
py -3 fc26_updater.py
goto finish

:run_python
python fc26_updater.py
goto finish

:run_python3
python3 fc26_updater.py
goto finish

:run_314
"%LocalAppData%\Programs\Python\Python314\python.exe" fc26_updater.py
goto finish

:run_313
"%LocalAppData%\Programs\Python\Python313\python.exe" fc26_updater.py
goto finish

:run_312
"%LocalAppData%\Programs\Python\Python312\python.exe" fc26_updater.py
goto finish

:run_311
"%LocalAppData%\Programs\Python\Python311\python.exe" fc26_updater.py
goto finish

:run_310
"%LocalAppData%\Programs\Python\Python310\python.exe" fc26_updater.py

:finish
if errorlevel 1 pause
endlocal
