# FC26 Squad Sync – PC Otomatik Kadro Güncelleyici

FC26 Squad Sync, EA SPORTS FC 26'nın PC kadro dosyasını oyun kurulmadan EA
sunucusundan indirir; transfer listesindeki mevcut FC26 oyuncularını hedef
kulüplere taşır, eski dosyayı yedekler ve yeni dosyayı yeniden açarak doğrular.

## Hızlı kullanım

1. ZIP dosyasını tamamen bir klasöre çıkarın.
2. `BASLAT.bat` dosyasına çift tıklayın.
3. Oyununuz yoksa **Resmi PC Kadrosunu İndir** düğmesine basın.
4. İndirme bitince **Güncellemeyi Oluştur** düğmesine basın. Program güncel
   transfer listesini internetten otomatik kontrol eder.
5. Sonuç `output` klasöründe oluşturulur.

FC26 sahibi kullanıcı, adı `SquadsFC26Sync...` ile başlayan çıktı dosyasını şu
klasöre kopyalamalıdır:

```text
%LOCALAPPDATA%\EA SPORTS FC 26\settings
```

Ardından oyunda **Özelleştir > Profil > Kadroları Yükle** bölümünden dosyayı
seçebilir. Yeni kariyer açılacaksa önce bu kadro yüklenmelidir.

## Program ne yapıyor?

- En güncel resmi PC64 kadro paketini EA sunucusundan indirir.
- En güncel transfer listesini `bunyaminbayraktar.github.io/data.json`
  adresinden indirir ve biçimini doğrular.
- İnternet kesilirse son sağlam önbelleği; o da yoksa paketle gelen doğrulanmış
  listeyi kullanır.
- Kaynak `Squads...` dosyasını tarihli `.bak` dosyası olarak yedekler.
- 3.223 transfer talebini oyuncu ve takım kimlikleriyle kontrol eder.
- Oyuncunun kulüp bağlantısını ve çakışan forma numarasını günceller.
- Eski ve yeni takımın varsayılan takım listesini düzeltir.
- Geçersiz eski kiralık kayıtlarını temizler.
- Oluşturulan dosyayı yeniden okuyup uygulanan her transferi doğrular.
- Ayrıntılı JSON ve Excel'de açılabilen CSV raporu üretir.

## 28 Ağustos 2026 doğrulama sonucu

EA'nın 23 Temmuz 2026 tarihli resmi PC kadrosu üzerinde:

- 3.219 transfer uygulandı ve doğrulandı.
- 4 oyuncu resmi PC kadrosunda bulunmadığı için güvenle atlandı.
- 723 farklı hedef kulübün tamamı FC26 takım kimliğiyle çözüldü.
- 83 veritabanı tablosunun tamamı çıktıdan yeniden okunabildi.

Atlanan dört oyuncu raporda `PLAYER_NOT_FOUND` olarak görünür: Fabio Ponsi,
Leonardo Suárez, Faik Sakar ve Waylon Renecke.

## Sınırlar ve güvenlik

- Bu araç **Ultimate Team veya çevrimiçi modlar için değildir**.
- Çıktı, çevrimdışı başlangıç kadroları ve bundan sonra açılacak kariyerler
  içindir; devam eden kariyeri değiştirmez.
- Veri kaynağında yeni transferin kiralık mı kalıcı mı olduğu bulunmadığından,
  uygulanan kadro hareketleri kalıcı kulüp değişikliği olarak yazılır.
- Oyunda hiç bulunmayan 3.133 gerçek oyuncu otomatik oluşturulmaz. Oyuncu
  oluşturmak için görünüş ve özellik verilerinin ayrıca hazırlanması gerekir.
- Program kaynak dosyayı değiştirmez; her çalışmada ayrı çıktı ve yedek üretir.
- Dosya biçimi oyun güncellemeleriyle değişebilir. Her çalıştırmadan sonra
  `rapor` klasöründeki sonucu kontrol edin.

## Komut satırı

En güncel resmi kadroyu indirip güncellemek:

```powershell
python fc26_updater.py --download
```

Mevcut bir kadro dosyasını güncellemek:

```powershell
python fc26_updater.py --input "C:\...\Squads..." --output-dir output
```

İnternet transfer listesini kontrol etmeden paketle gelen listeyi kullanmak:

```powershell
python fc26_updater.py --download --offline
```

## Gereksinim

- Windows 10/11
- Python 3.10 veya daha yeni sürüm (yalnızca standart kütüphane kullanılır)

## Lisans ve kaynaklar

Uygulama MIT lisanslıdır. FC26 T3DB/FBCHUNKS dosya okuma kodu
`INSANE0777/Fc26-live-editor-mcp`, EA paket açma ve sarmalama mantığı
`xAranaktu/FIFASquadFileDownloader` projelerinden MIT lisansı altında
uyarlanmıştır. İlgili lisans metinleri `licenses` klasöründedir.

EA SPORTS FC, Electronic Arts'ın ticari markasıdır. Bu proje Electronic Arts
tarafından desteklenmemekte veya onaylanmamaktadır.
