import json
import os
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fc26_core import SquadUpdater, load_transfers, normalize_name


class CoreTests(unittest.TestCase):
    def test_normalization(self):
        self.assertEqual(normalize_name("Kadro FC Bayern München"), "fcbayernmunchen")
        self.assertEqual(normalize_name("Brighton & Hove Albion"), "brightonandhovealbion")

    def test_transfer_ids_are_unique(self):
        rows = load_transfers(ROOT / "data" / "transfers.json")
        ids = [int(row["fc_id"]) for row in rows]
        self.assertEqual(len(rows), 3223)
        self.assertEqual(len(ids), len(set(ids)))

    def test_alias_file_is_valid_json(self):
        aliases = json.loads((ROOT / "data" / "team_aliases.json").read_text(encoding="utf-8"))
        self.assertEqual(len(aliases), 121)
        self.assertTrue(all(isinstance(teamid, int) for teamid in aliases.values()))

    @unittest.skipUnless(os.environ.get("FC26_TEST_SQUAD"), "FC26_TEST_SQUAD ayarlanmadı")
    def test_every_target_resolves_on_real_squad(self):
        updater = SquadUpdater(
            Path(os.environ["FC26_TEST_SQUAD"]),
            ROOT / "data" / "fifa_ng_db-meta-fc26.xml",
            ROOT / "data" / "team_aliases.json",
        )
        rows = load_transfers(ROOT / "data" / "transfers.json")
        unresolved = sorted({row["target"] for row in rows if updater.resolve_team(row["target"])[0] is None})
        self.assertEqual(unresolved, [])


if __name__ == "__main__":
    unittest.main()
