import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fc26_transfer_feed import get_latest_transfers


class TransferFeedTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.bundled = self.root / "bundled.json"
        self.cache = self.root / "cache.json"
        self.bundled.write_text(
            json.dumps({"transfers": [{"fc_id": "1", "target": "A"}]}),
            encoding="utf-8",
        )

    def tearDown(self):
        self.temp.cleanup()

    @patch("fc26_transfer_feed.download_transfer_feed")
    def test_online_feed_is_cached(self, download):
        online = [{"fc_id": str(index), "target": "A"} for index in range(1, 101)]
        download.return_value = online
        transfers, info = get_latest_transfers(self.bundled, self.cache, lambda _: None)
        self.assertEqual(100, len(transfers))
        self.assertEqual("online", info["kind"])
        self.assertTrue(self.cache.is_file())

    @patch("fc26_transfer_feed.download_transfer_feed", side_effect=OSError("offline"))
    def test_bundled_feed_is_safe_fallback(self, _download):
        transfers, info = get_latest_transfers(self.bundled, self.cache, lambda _: None)
        self.assertEqual(1, len(transfers))
        self.assertEqual("bundled", info["kind"])


if __name__ == "__main__":
    unittest.main()
