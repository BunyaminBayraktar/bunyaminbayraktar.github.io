#!/usr/bin/env python3
"""Download and safely cache the current FC26 Squad Sync transfer feed."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
from urllib.request import Request, urlopen

from fc26_core import load_transfers, parse_transfers


Progress = Callable[[str], None]
MAX_FEED_BYTES = 25 * 1024 * 1024
MIN_ONLINE_TRANSFERS = 100
TRANSFER_FEED_URLS = (
    "https://bunyaminbayraktar.github.io/data.json",
    "https://raw.githubusercontent.com/BunyaminBayraktar/"
    "bunyaminbayraktar.github.io/main/docs/data.json",
)


def default_cache_path(app_dir: Path) -> Path:
    local_app_data = os.environ.get("LOCALAPPDATA")
    root = Path(local_app_data) if local_app_data else app_dir
    return root / "FC26 Squad Sync" / "transfers-cache.json"


def download_transfer_feed(url: str, timeout: int = 25) -> list[dict]:
    request = Request(
        url,
        headers={
            "User-Agent": "FC26-Squad-Sync/0.2",
            "Accept": "application/json",
        },
    )
    with urlopen(request, timeout=timeout) as response:
        content_type = response.headers.get("Content-Type", "").lower()
        if "json" not in content_type and "text/plain" not in content_type:
            raise ValueError(f"Beklenmeyen içerik türü: {content_type or 'bilinmiyor'}")
        raw = response.read(MAX_FEED_BYTES + 1)
    if len(raw) > MAX_FEED_BYTES:
        raise ValueError("Çevrimiçi transfer listesi izin verilen boyutu aşıyor.")
    data = json.loads(raw.decode("utf-8-sig"))
    transfers = parse_transfers(data)
    if len(transfers) < MIN_ONLINE_TRANSFERS:
        raise ValueError(
            f"Çevrimiçi listede yalnızca {len(transfers)} kayıt var; güvenlik için kullanılmadı."
        )
    return transfers


def save_cache(cache_path: Path, source_url: str, transfers: list[dict]) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "source_url": source_url,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "transfers": transfers,
    }
    temporary = cache_path.with_suffix(cache_path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(cache_path)


def get_latest_transfers(
    bundled_path: Path,
    cache_path: Path,
    progress: Progress = print,
    online: bool = True,
) -> tuple[list[dict], dict]:
    errors: list[str] = []
    if online:
        progress("Güncel transfer listesi internetten kontrol ediliyor…")
        for url in TRANSFER_FEED_URLS:
            try:
                transfers = download_transfer_feed(url)
                save_cache(cache_path, url, transfers)
                progress(f"Güncel transfer listesi alındı: {len(transfers)} kayıt.")
                return transfers, {
                    "kind": "online",
                    "source": url,
                    "count": len(transfers),
                }
            except Exception as exc:
                errors.append(f"{url}: {exc}")

    if cache_path.is_file():
        try:
            transfers = load_transfers(cache_path)
            progress(f"İnternet listesine ulaşılamadı; önbellekteki {len(transfers)} kayıt kullanılıyor.")
            return transfers, {
                "kind": "cache",
                "source": str(cache_path),
                "count": len(transfers),
                "online_errors": errors,
            }
        except Exception as exc:
            errors.append(f"Önbellek: {exc}")

    transfers = load_transfers(bundled_path)
    progress(f"Paketle gelen doğrulanmış liste kullanılıyor: {len(transfers)} kayıt.")
    return transfers, {
        "kind": "bundled",
        "source": str(bundled_path),
        "count": len(transfers),
        "online_errors": errors,
    }
