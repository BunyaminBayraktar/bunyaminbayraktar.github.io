"""Safe, offline bulk transfer updater for FC 26 squad files."""

from __future__ import annotations

import csv
import json
import re
import shutil
import unicodedata
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

from vendor.fifa_squad import SquadFile


FREE_AGENT_TEAM_ID = 111592
Progress = Callable[[str], None]


@dataclass
class TransferResult:
    status: str
    playerid: int
    player: str
    source_expected: str
    source_actual: str
    target_requested: str
    target_resolved: str
    target_teamid: int | None
    note: str = ""


def normalize_name(value: str) -> str:
    value = re.sub(r"^Kadro\s+", "", str(value), flags=re.IGNORECASE)
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    value = value.casefold().replace("&", "and")
    return re.sub(r"[^a-z0-9]", "", value)


def parse_transfers(data: object) -> list[dict]:
    rows = data.get("transfers", data) if isinstance(data, dict) else data
    if not isinstance(rows, list):
        raise ValueError("Transfer verisi liste biçiminde değil.")
    seen: set[int] = set()
    clean = []
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Transfer kaydı nesne biçiminde değil.")
        playerid = int(row["fc_id"])
        if playerid <= 0:
            raise ValueError(f"Geçersiz FC oyuncu kimliği: {playerid}")
        if playerid in seen:
            raise ValueError(f"Tekrarlanan FC oyuncu kimliği: {playerid}")
        if not str(row.get("target") or "").strip():
            raise ValueError(f"Hedef takımı eksik transfer kaydı: {playerid}")
        seen.add(playerid)
        clean.append(row)
    return clean


def load_transfers(path: Path) -> list[dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return parse_transfers(data)


def _sheet_player_fields(sheet: dict) -> list[str]:
    fields = [name for name in sheet if re.fullmatch(r"playerid\d+", name)]
    return sorted(fields, key=lambda name: int(name[8:]))


def _sheet_special_fields(sheet: dict) -> list[str]:
    fixed = {
        "captainid", "longkicktakerid", "rightcornerkicktakerid",
        "leftcornerkicktakerid", "penaltytakerid", "freekicktakerid",
        "leftfreekicktakerid", "rightfreekicktakerid",
        "customsub0in", "customsub0out", "customsub1in", "customsub1out",
        "customsub2in", "customsub2out",
    }
    return [name for name in sheet if name in fixed]


class SquadUpdater:
    def __init__(self, squad_path: Path, meta_path: Path, aliases_path: Path):
        self.squad_path = Path(squad_path)
        self.squad = SquadFile(str(squad_path), str(meta_path))
        self.aliases = {
            key: int(value)
            for key, value in json.loads(aliases_path.read_text(encoding="utf-8")).items()
        }
        self.teams = self.squad.get_table("teams")
        self.team_by_id = {int(team["teamid"]): team for team in self.teams}
        self.male_teams = [team for team in self.teams if int(team.get("gender") or 0) == 0]
        self.exact_team_names: dict[str, list[dict]] = defaultdict(list)
        for team in self.male_teams:
            self.exact_team_names[normalize_name(team.get("teamname", ""))].append(team)

        invalid_aliases = [
            name for name, teamid in self.aliases.items()
            if teamid not in self.team_by_id
            or int(self.team_by_id[teamid].get("gender") or 0) != 0
        ]
        if invalid_aliases:
            raise ValueError("Geçersiz takım eşleştirmeleri: " + ", ".join(invalid_aliases))

    def resolve_team(self, requested: str) -> tuple[int | None, str]:
        if requested in self.aliases:
            team = self.team_by_id[self.aliases[requested]]
            return int(team["teamid"]), str(team.get("teamname") or "")
        matches = self.exact_team_names.get(normalize_name(requested), [])
        if len(matches) == 1:
            team = matches[0]
            return int(team["teamid"]), str(team.get("teamname") or "")
        return None, ""

    def apply(self, transfers: list[dict], output_path: Path,
              progress: Progress | None = None) -> tuple[dict, list[TransferResult]]:
        players = {int(player["playerid"]): player for player in self.squad.get_table("players")}
        links = self.squad.get_table("teamplayerlinks")
        loans = self.squad.get_table("playerloans")
        sheets = self.squad.get_table("default_teamsheets")
        sheet_index = {int(sheet["teamid"]): idx for idx, sheet in enumerate(sheets)}

        club_ids = {
            int(team["teamid"]) for team in self.male_teams
            if int(team.get("clubworth") or 0) != 0
        } | {FREE_AGENT_TEAM_ID}
        link_indexes_by_player: dict[int, list[int]] = defaultdict(list)
        jerseys_by_team: dict[int, set[int]] = defaultdict(set)
        for idx, link in enumerate(links):
            pid, teamid = int(link["playerid"]), int(link["teamid"])
            link_indexes_by_player[pid].append(idx)
            if teamid in club_ids:
                number = int(link.get("jerseynumber") or 0)
                if 1 <= number <= 99:
                    jerseys_by_team[teamid].add(number)
        loans_by_player: dict[int, list[int]] = defaultdict(list)
        for idx, loan in enumerate(loans):
            loans_by_player[int(loan["playerid"])].append(idx)

        results: list[TransferResult] = []
        loan_indexes_to_delete: set[int] = set()
        applied = 0

        for order, row in enumerate(transfers, start=1):
            if progress and (order == 1 or order % 100 == 0):
                progress(f"Transferler uygulanıyor: {order}/{len(transfers)}")
            playerid = int(row["fc_id"])
            player_name = str(row.get("player") or f"Player#{playerid}")
            source_expected = str(row.get("source") or "")
            target_requested = str(row.get("target") or "")
            target_id, target_name = self.resolve_team(target_requested)

            if playerid not in players:
                results.append(TransferResult("PLAYER_NOT_FOUND", playerid, player_name,
                                              source_expected, "", target_requested,
                                              target_name, target_id,
                                              "Oyuncu resmi 23.07.2026 PC kadrosunda yok."))
                continue
            if target_id is None:
                results.append(TransferResult("TEAM_NOT_FOUND", playerid, player_name,
                                              source_expected, "", target_requested,
                                              "", None, "Hedef takım güvenle eşleştirilemedi."))
                continue

            all_link_indexes = link_indexes_by_player.get(playerid, [])
            club_link_indexes = [
                idx for idx in all_link_indexes if int(links[idx]["teamid"]) in club_ids
            ]
            if len(club_link_indexes) > 1:
                source_matches = [
                    idx for idx in club_link_indexes
                    if normalize_name(self.team_by_id.get(int(links[idx]["teamid"]), {}).get("teamname", ""))
                    == normalize_name(source_expected)
                ]
                if len(source_matches) == 1:
                    club_link_indexes = source_matches
            if not club_link_indexes and len(all_link_indexes) == 1:
                club_link_indexes = all_link_indexes
            if len(club_link_indexes) != 1:
                results.append(TransferResult("CLUB_LINK_AMBIGUOUS", playerid, player_name,
                                              source_expected, "", target_requested,
                                              target_name, target_id,
                                              f"Kulüp bağlantısı sayısı: {len(club_link_indexes)}"))
                continue

            link_idx = club_link_indexes[0]
            old_team_id = int(links[link_idx]["teamid"])
            old_team_name = str(self.team_by_id.get(old_team_id, {}).get("teamname") or old_team_id)
            if old_team_id == target_id:
                results.append(TransferResult("ALREADY_CORRECT", playerid, player_name,
                                              source_expected, old_team_name, target_requested,
                                              target_name, target_id))
                continue

            old_number = int(links[link_idx].get("jerseynumber") or 0)
            jerseys_by_team[old_team_id].discard(old_number)
            new_number = old_number if 1 <= old_number <= 99 and old_number not in jerseys_by_team[target_id] else 0
            if not new_number:
                new_number = next((number for number in range(1, 100)
                                   if number not in jerseys_by_team[target_id]), 99)
            jerseys_by_team[target_id].add(new_number)

            self.squad.update_field("teamplayerlinks", link_idx, "teamid", target_id)
            self.squad.update_field("teamplayerlinks", link_idx, "jerseynumber", new_number)
            links[link_idx]["teamid"] = target_id
            links[link_idx]["jerseynumber"] = new_number

            self._remove_from_sheet(sheets, sheet_index, old_team_id, playerid)
            self._add_to_sheet(sheets, sheet_index, target_id, playerid)
            loan_indexes_to_delete.update(loans_by_player.get(playerid, []))

            applied += 1
            results.append(TransferResult("APPLIED", playerid, player_name,
                                          source_expected, old_team_name, target_requested,
                                          target_name, target_id,
                                          f"Forma numarası: {new_number}"))

        if progress and loan_indexes_to_delete:
            progress(f"{len(loan_indexes_to_delete)} eski kiralık kaydı temizleniyor…")
        for loan_idx in sorted(loan_indexes_to_delete, reverse=True):
            self.squad.delete_record("playerloans", loan_idx)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        self.squad.save(str(output_path))
        summary = {
            "input": str(self.squad_path),
            "output": str(output_path),
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "total": len(transfers),
            "applied": applied,
            "already_correct": sum(r.status == "ALREADY_CORRECT" for r in results),
            "skipped": sum(r.status not in {"APPLIED", "ALREADY_CORRECT"} for r in results),
            "removed_loan_records": len(loan_indexes_to_delete),
        }
        return summary, results

    def _remove_from_sheet(self, sheets: list[dict], sheet_index: dict[int, int],
                           teamid: int, playerid: int) -> None:
        idx = sheet_index.get(teamid)
        if idx is None:
            return
        sheet = sheets[idx]
        player_fields = _sheet_player_fields(sheet)
        remaining = [int(sheet[field]) for field in player_fields
                     if int(sheet[field]) not in {-1, playerid}]
        replacement = remaining[0] if remaining else -1
        for field in player_fields:
            if int(sheet[field]) == playerid:
                self.squad.update_field("default_teamsheets", idx, field, -1)
                sheet[field] = -1
        for field in _sheet_special_fields(sheet):
            if int(sheet.get(field) or -1) == playerid:
                value = -1 if field.startswith("customsub") else replacement
                self.squad.update_field("default_teamsheets", idx, field, value)
                sheet[field] = value

    def _add_to_sheet(self, sheets: list[dict], sheet_index: dict[int, int],
                      teamid: int, playerid: int) -> None:
        idx = sheet_index.get(teamid)
        if idx is None:
            return
        sheet = sheets[idx]
        fields = _sheet_player_fields(sheet)
        if any(int(sheet[field]) == playerid for field in fields):
            return
        reserve_first = sorted(fields, key=lambda field: (int(field[8:]) < 11, int(field[8:])))
        free = next((field for field in reserve_first if int(sheet[field]) == -1), None)
        if free:
            self.squad.update_field("default_teamsheets", idx, free, playerid)
            sheet[free] = playerid


def write_reports(directory: Path, summary: dict, results: list[TransferResult]) -> tuple[Path, Path]:
    directory.mkdir(parents=True, exist_ok=True)
    json_path = directory / "guncelleme_raporu.json"
    csv_path = directory / "guncelleme_raporu.csv"
    payload = {"summary": summary, "results": [asdict(row) for row in results]}
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        fieldnames = list(asdict(results[0]).keys()) if results else list(TransferResult.__annotations__)
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(asdict(row) for row in results)
    return json_path, csv_path


def make_backup(source: Path, backup_directory: Path) -> Path:
    backup_directory.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = backup_directory / f"{source.name}.{stamp}.bak"
    shutil.copy2(source, backup)
    return backup
