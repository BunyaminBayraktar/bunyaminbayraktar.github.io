"""Download and wrap the latest official EA SPORTS FC 26 PC squad database.

The decompression and FBCHUNKS wrapper layout are adapted from
xAranaktu/FIFASquadFileDownloader (MIT). TLS verification is intentionally
left enabled here.
"""

from __future__ import annotations

import os
import struct
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable


CONTENT_ROOT = (
    "https://eafc26.content.easports.com/fc/fltOnlineAssets/"
    "26E4D4D6-8DBB-4A9A-BD99-9C47D3AA341D/2026/"
)
ROSTER_XML = "fc/fclive/genxtitle/rosterupdate.xml"
T3DB = b"\x44\x42\x00\x08"
FBCHUNKS = b"\x46\x42\x43\x48\x55\x4E\x4B\x53\x01\x00"
BNRY = (
    b"\x42\x4E\x52\x59\x00\x00\x00\x02\x4C\x54\x4C\x45\x01\x01\x03\x00"
    b"\x00\x00\x63\x64\x73\x01\x00\x00\x00\x00\x01\x03\x00\x00\x00\x63\x64\x73"
)

Progress = Callable[[str], None]


@dataclass(frozen=True)
class RosterInfo:
    version: str
    source_date: str
    relative_url: str


def _request(url: str):
    request = urllib.request.Request(url, headers={"User-Agent": "FC26-Squad-Sync/1.0"})
    return urllib.request.urlopen(request, timeout=60)


def _validate_ea_url(url: str) -> None:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname != "eafc26.content.easports.com":
        raise ValueError("Beklenmeyen indirme adresi reddedildi.")
    if "/fc/fltOnlineAssets/" not in parsed.path:
        raise ValueError("EA kadro dizini dışındaki adres reddedildi.")


def latest_pc_roster() -> RosterInfo:
    url = urllib.parse.urljoin(CONTENT_ROOT, ROSTER_XML)
    _validate_ea_url(url)
    with _request(url) as response:
        root = ET.fromstring(response.read())

    node = root.find("./squadInfoSet/squadInfo[@platform='pc64']")
    if node is None:
        raise RuntimeError("EA kadro bildiriminde PC64 kaydı bulunamadı.")
    loc = (node.findtext("dbMajorLoc") or "").strip()
    version = (node.findtext("dbMajor") or "").strip()
    if not loc or not version:
        raise RuntimeError("EA PC64 kadro bilgisi eksik.")
    filename = os.path.basename(loc)
    parts = filename.split("_")
    source_date = parts[1] if len(parts) > 1 and len(parts[1]) == 8 else "unknown"
    return RosterInfo(version=version, source_date=source_date, relative_url=loc)


def download_file(url: str, destination: Path, progress: Progress | None = None) -> None:
    _validate_ea_url(url)
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".part")
    try:
        with _request(url) as response, partial.open("wb") as target:
            total = int(response.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                target.write(chunk)
                done += len(chunk)
                if progress and total:
                    progress(f"EA kadrosu indiriliyor: %{done * 100 // total}")
        if partial.stat().st_size < 100_000:
            raise RuntimeError("İndirilen EA kadro paketi beklenenden küçük.")
        partial.replace(destination)
    finally:
        if partial.exists():
            partial.unlink()


def unpack_ea_db(path: Path) -> bytes:
    data = path.read_bytes()
    if len(data) < 16:
        raise ValueError("EA kadro paketi geçersiz veya eksik.")
    size = int.from_bytes(data[2:5], "big")
    if size < 1_000_000 or size > 100_000_000:
        raise ValueError("EA kadro veritabanı boyutu güvenlik sınırının dışında.")

    out = bytearray(size)
    out[: len(T3DB)] = T3DB
    ipos, opos, last_control = 10, len(T3DB), 0

    def copy_back(offset: int, length: int) -> None:
        nonlocal opos
        if offset <= 0 or offset > opos or opos + length > len(out):
            raise ValueError("EA kadro paketi açılırken geçersiz geri başvuru bulundu.")
        source = opos - offset
        for _ in range(length):
            out[opos] = out[source]
            opos += 1
            source += 1

    def copy_literal(length: int) -> None:
        nonlocal ipos, opos
        if ipos + length > len(data) or opos + length > len(out):
            raise ValueError("EA kadro paketi açılırken veri sınırı aşıldı.")
        out[opos : opos + length] = data[ipos : ipos + length]
        ipos += length
        opos += length

    while ipos < len(data) and opos < len(out):
        control = data[ipos]
        last_control = control
        ipos += 1
        if not (control & 0x80):
            if ipos >= len(data):
                break
            b1 = data[ipos]
            ipos += 1
            copy_literal(control & 3)
            copy_back(b1 + ((control & 0x60) << 3) + 1, ((control >> 2) & 7) + 3)
        elif not (control & 0x40):
            if ipos + 2 > len(data):
                break
            b2, b3 = data[ipos : ipos + 2]
            ipos += 2
            copy_literal(b2 >> 6)
            copy_back(((b2 & 0x3F) << 8 | b3) + 1, (control & 0x3F) + 4)
        elif not (control & 0x20):
            if ipos + 3 > len(data):
                break
            b2, b3, b4 = data[ipos : ipos + 3]
            ipos += 3
            copy_literal(control & 3)
            copy_back((((control & 0x10) << 12) | (b2 << 8) | b3) + 1,
                      b4 + ((control & 0x0C) << 6) + 5)
        else:
            literal = (control & 0x1F) * 4 + 4
            if literal > 0x70:
                break
            copy_literal(literal)

    trailing = last_control & 3
    if trailing and opos < len(out):
        copy_literal(min(trailing, len(out) - opos))
    if not out.startswith(T3DB):
        raise ValueError("Açılan dosyada T3DB imzası bulunamadı.")
    return bytes(out)


def write_squad_wrapper(db: bytes, output: Path) -> None:
    prefix_size = 1126
    main_header_size = 48
    bnry_size = 45985
    file_size = main_header_size + 4 + len(db) + bnry_size

    prefix = bytearray(prefix_size)
    pos = 0
    prefix[pos : pos + len(FBCHUNKS)] = FBCHUNKS
    pos += len(FBCHUNKS)
    prefix[pos : pos + 4] = (prefix_size - pos - 8).to_bytes(4, "little")
    pos += 4
    prefix[pos : pos + 4] = file_size.to_bytes(4, "little")
    pos += 4
    in_game_name = ("EA_" + output.name).encode("ascii", errors="ignore")[:40]
    prefix[pos : pos + len(in_game_name)] = in_game_name
    pos += len(in_game_name) + 7
    prefix[pos : pos + len(b"Aranaktu")] = b"Aranaktu"

    main = bytearray(main_header_size)
    save_type = b"SaveType_Squads\x00"
    main[: len(save_type)] = save_type
    main[len(save_type) : len(save_type) + 4] = (0).to_bytes(4, "little")

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as handle:
        handle.write(prefix)
        handle.write(main)
        handle.write((len(db) + bnry_size).to_bytes(4, "little"))
        handle.write(db)
        handle.write(BNRY)
        handle.write(b"\x00" * (bnry_size - len(BNRY)))


def download_latest_pc_squad(directory: Path, progress: Progress | None = None) -> Path:
    if progress:
        progress("EA kadro sürümü kontrol ediliyor…")
    info = latest_pc_roster()
    if progress:
        progress(f"Resmi PC kadrosu bulundu: {info.source_date} / sürüm {info.version}")
    package = directory / f"ea_pc64_{info.source_date}_{info.version}.bin"
    url = urllib.parse.urljoin(CONTENT_ROOT, info.relative_url)
    download_file(url, package, progress)
    if progress:
        progress("EA kadro paketi açılıyor…")
    db = unpack_ea_db(package)
    stamp = info.source_date if info.source_date != "unknown" else datetime.now().strftime("%Y%m%d")
    output = directory / f"Squads{stamp}000000"
    write_squad_wrapper(db, output)
    if progress:
        progress(f"Resmi PC kadrosu hazır: {output.name}")
    return output
