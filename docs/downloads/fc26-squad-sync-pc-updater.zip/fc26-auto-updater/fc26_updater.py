#!/usr/bin/env python3
"""FC26 Squad Sync – Windows GUI and command-line entry point."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path

from fc26_core import SquadUpdater, make_backup, write_reports
from fc26_download import download_latest_pc_squad
from fc26_transfer_feed import default_cache_path, get_latest_transfers
from vendor.fifa_squad import SquadFile


APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
META_PATH = DATA_DIR / "fifa_ng_db-meta-fc26.xml"
TRANSFERS_PATH = DATA_DIR / "transfers.json"
ALIASES_PATH = DATA_DIR / "team_aliases.json"


def verify_output(output_path: Path, results) -> int:
    squad = SquadFile(str(output_path), str(META_PATH))
    teams = {int(team["teamid"]): team for team in squad.get_table("teams")}
    club_ids = {
        teamid for teamid, team in teams.items()
        if int(team.get("gender") or 0) == 0 and int(team.get("clubworth") or 0) != 0
    } | {111592}
    current: dict[int, set[int]] = {}
    for link in squad.get_table("teamplayerlinks"):
        playerid, teamid = int(link["playerid"]), int(link["teamid"])
        if teamid in club_ids:
            current.setdefault(playerid, set()).add(teamid)

    verified = 0
    failures = []
    for row in results:
        if row.status not in {"APPLIED", "ALREADY_CORRECT"}:
            continue
        if row.target_teamid in current.get(row.playerid, set()):
            verified += 1
        else:
            failures.append(f"{row.player} ({row.playerid})")
    if failures:
        raise RuntimeError("Çıktı doğrulamasında başarısız oyuncular: " + ", ".join(failures[:10]))
    return verified


def run_update(
    input_path: Path,
    output_directory: Path,
    progress=print,
    online_transfers: bool = True,
) -> tuple[dict, Path]:
    input_path = input_path.resolve()
    output_directory = output_directory.resolve()
    if not input_path.is_file():
        raise FileNotFoundError(f"Kadro dosyası bulunamadı: {input_path}")
    if not input_path.name.startswith("Squads"):
        raise ValueError("Seçilen dosyanın adı 'Squads' ile başlamalıdır.")

    transfers, transfer_feed = get_latest_transfers(
        TRANSFERS_PATH,
        default_cache_path(APP_DIR),
        progress,
        online=online_transfers,
    )
    progress("Orijinal kadro yedekleniyor…")
    backup = make_backup(input_path, output_directory / "backup")

    stamp = datetime.now().strftime("%Y%m%d%H%M%S")
    output_path = output_directory / f"SquadsFC26Sync{stamp}"
    updater = SquadUpdater(input_path, META_PATH, ALIASES_PATH)
    summary, results = updater.apply(transfers, output_path, progress)
    summary["backup"] = str(backup)
    summary["transfer_feed"] = transfer_feed

    progress("Oluşturulan kadro dosyası yeniden açılıp doğrulanıyor…")
    summary["verified"] = verify_output(output_path, results)
    report_dir = output_directory / "rapor"
    json_report, csv_report = write_reports(report_dir, summary, results)
    summary["json_report"] = str(json_report)
    summary["csv_report"] = str(csv_report)
    progress(
        f"Tamamlandı: {summary['applied']} transfer uygulandı, "
        f"{summary['already_correct']} kayıt zaten doğruydu, {summary['skipped']} kayıt atlandı."
    )
    return summary, output_path


def open_directory(path: Path) -> None:
    if sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


class App:
    def __init__(self):
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk

        self.tk = tk
        self.filedialog = filedialog
        self.messagebox = messagebox
        self.root = tk.Tk()
        self.root.title("FC26 Squad Sync – Otomatik PC Kadro Güncelleyici")
        self.root.geometry("820x620")
        self.root.minsize(760, 560)
        self.root.configure(bg="#071a33")
        self.selected_file: Path | None = None
        self.output_dir = APP_DIR / "output"

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TProgressbar", troughcolor="#112b49", background="#21d4a7")

        header = tk.Frame(self.root, bg="#071a33", padx=32, pady=26)
        header.pack(fill="x")
        tk.Label(header, text="FC26 SQUAD SYNC", bg="#071a33", fg="white",
                 font=("Segoe UI", 24, "bold")).pack(anchor="w")
        tk.Label(header, text="PC için otomatik ve yedekli kadro güncelleyici",
                 bg="#071a33", fg="#9fc3e6", font=("Segoe UI", 11)).pack(anchor="w", pady=(5, 0))

        card = tk.Frame(self.root, bg="#ffffff", padx=28, pady=24)
        card.pack(fill="both", expand=True, padx=32, pady=(0, 28))

        tk.Label(card, text="1. Başlangıç kadrosunu seç", bg="white", fg="#071a33",
                 font=("Segoe UI", 15, "bold")).pack(anchor="w")
        tk.Label(card, text="Oyunun yoksa resmi PC kadrosunu EA sunucusundan ücretsiz indirebiliriz.",
                 bg="white", fg="#56697d", font=("Segoe UI", 10)).pack(anchor="w", pady=(4, 14))

        row = tk.Frame(card, bg="white")
        row.pack(fill="x")
        self.download_button = tk.Button(
            row, text="Resmi PC Kadrosunu İndir", command=self.download,
            bg="#0d6efd", fg="white", activebackground="#0b5ed7", activeforeground="white",
            relief="flat", padx=18, pady=11, font=("Segoe UI", 10, "bold"), cursor="hand2"
        )
        self.download_button.pack(side="left")
        self.select_button = tk.Button(
            row, text="Mevcut Squads Dosyasını Seç", command=self.select_file,
            bg="#e9f1f8", fg="#12385e", activebackground="#dbe8f3", relief="flat",
            padx=18, pady=11, font=("Segoe UI", 10, "bold"), cursor="hand2"
        )
        self.select_button.pack(side="left", padx=(12, 0))

        self.file_label = tk.Label(card, text="Henüz dosya seçilmedi", bg="white", fg="#6c7c8c",
                                   font=("Segoe UI", 9), wraplength=690, justify="left")
        self.file_label.pack(anchor="w", pady=(12, 20))

        tk.Frame(card, bg="#dfe8f1", height=1).pack(fill="x", pady=(0, 20))
        tk.Label(card, text="2. Güncellenmiş kadroyu oluştur", bg="white", fg="#071a33",
                 font=("Segoe UI", 15, "bold")).pack(anchor="w")
        tk.Label(card, text="Program güncel transfer listesini internetten alır, yedekler ve sonucu doğrular.",
                 bg="white", fg="#56697d", font=("Segoe UI", 10)).pack(anchor="w", pady=(4, 14))

        self.update_button = tk.Button(
            card, text="Güncellemeyi Oluştur", command=self.update, state="disabled",
            bg="#19a974", fg="white", disabledforeground="#d2d8dc",
            activebackground="#14875d", activeforeground="white", relief="flat",
            padx=20, pady=12, font=("Segoe UI", 11, "bold"), cursor="hand2"
        )
        self.update_button.pack(anchor="w")

        self.progress = ttk.Progressbar(card, mode="indeterminate")
        self.progress.pack(fill="x", pady=(22, 10))
        self.status = tk.Label(card, text="Hazır", bg="white", fg="#34516d",
                               font=("Segoe UI", 10), wraplength=700, justify="left")
        self.status.pack(anchor="w")

        self.result = tk.Label(card, text="", bg="white", fg="#0b7a53",
                               font=("Segoe UI", 11, "bold"), wraplength=700, justify="left")
        self.result.pack(anchor="w", pady=(12, 0))
        self.open_button = tk.Button(
            card, text="Çıktı Klasörünü Aç", command=lambda: open_directory(self.output_dir),
            bg="#071a33", fg="white", activebackground="#12385e", activeforeground="white",
            relief="flat", padx=16, pady=9, font=("Segoe UI", 9, "bold"), cursor="hand2"
        )

    def set_busy(self, busy: bool):
        state = "disabled" if busy else "normal"
        self.download_button.configure(state=state)
        self.select_button.configure(state=state)
        self.update_button.configure(state="disabled" if busy or not self.selected_file else "normal")
        if busy:
            self.progress.start(12)
        else:
            self.progress.stop()

    def say(self, text: str):
        self.root.after(0, lambda: self.status.configure(text=text))

    def select_file(self):
        chosen = self.filedialog.askopenfilename(
            title="FC26 Squads dosyasını seç",
            filetypes=[("FC26 Squads dosyaları", "Squads*"), ("Tüm dosyalar", "*.*")],
        )
        if chosen:
            self.selected_file = Path(chosen)
            self.file_label.configure(text=str(self.selected_file), fg="#12385e")
            self.update_button.configure(state="normal")

    def download(self):
        self.set_busy(True)
        self.result.configure(text="")

        def task():
            try:
                work = APP_DIR / "downloaded"
                path = download_latest_pc_squad(work, self.say)
                self.selected_file = path
                self.root.after(0, lambda: self.file_label.configure(text=str(path), fg="#12385e"))
                self.say("Resmi PC kadrosu hazır. Şimdi 'Güncellemeyi Oluştur' düğmesine basabilirsin.")
            except Exception as exc:
                self.root.after(0, lambda: self.messagebox.showerror("İndirme hatası", str(exc)))
                self.say("İndirme tamamlanamadı.")
            finally:
                self.root.after(0, lambda: self.set_busy(False))

        threading.Thread(target=task, daemon=True).start()

    def update(self):
        if not self.selected_file:
            return
        self.set_busy(True)
        self.result.configure(text="")

        def task():
            try:
                summary, output = run_update(self.selected_file, self.output_dir, self.say)
                feed_label = {
                    "online": "internet",
                    "cache": "önbellek",
                    "bundled": "paket",
                }.get(summary["transfer_feed"]["kind"], summary["transfer_feed"]["kind"])
                message = (
                    f"✓ {summary['applied']} transfer uygulandı · "
                    f"{summary['already_correct']} zaten doğru · {summary['skipped']} kontrol gerekli\n"
                    f"Liste: {summary['transfer_feed']['count']} kayıt ({feed_label})\n"
                    f"Dosya: {output.name}"
                )
                self.root.after(0, lambda: self.result.configure(text=message))
                self.root.after(0, lambda: self.open_button.pack(anchor="w", pady=(14, 0)))
                self.root.after(0, lambda: self.messagebox.showinfo(
                    "Kadro hazır",
                    "Güncellenmiş kadro başarıyla oluşturuldu ve yeniden açılarak doğrulandı."
                ))
            except Exception as exc:
                details = traceback.format_exc()
                (APP_DIR / "hata.log").write_text(details, encoding="utf-8")
                self.root.after(0, lambda: self.messagebox.showerror(
                    "Güncelleme hatası", f"{exc}\n\nAyrıntılar hata.log dosyasına yazıldı."
                ))
                self.say("Güncelleme tamamlanamadı.")
            finally:
                self.root.after(0, lambda: self.set_busy(False))

        threading.Thread(target=task, daemon=True).start()

    def run(self):
        self.root.mainloop()


def parse_args():
    parser = argparse.ArgumentParser(description="FC26 Squad Sync PC kadro güncelleyici")
    parser.add_argument("--input", type=Path, help="Squads ile başlayan kaynak kadro dosyası")
    parser.add_argument("--download", action="store_true", help="En güncel resmi PC kadrosunu indir")
    parser.add_argument("--offline", action="store_true", help="İnternet listesini kontrol etmeden yerel listeyi kullan")
    parser.add_argument("--output-dir", type=Path, default=APP_DIR / "output")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.input or args.download:
        source = args.input
        if args.download:
            source = download_latest_pc_squad(APP_DIR / "downloaded", print)
        if source is None:
            raise SystemExit("Kaynak kadro dosyası belirtilmedi.")
        summary, output = run_update(source, args.output_dir, print, online_transfers=not args.offline)
        print(f"\nÇıktı: {output}")
        print(f"Doğrulanan: {summary['verified']}")
        return
    App().run()


if __name__ == "__main__":
    main()
