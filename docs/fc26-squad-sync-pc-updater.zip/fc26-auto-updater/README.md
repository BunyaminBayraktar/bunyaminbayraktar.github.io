# FC26 Squad Sync – PC Kadro Güncelleyici

FC26 Squad Sync, kullanıcının yasal FC26 kurulumuna ait kendi `Squads...`
dosyasının bir kopyası üzerinde doğrulanmış transfer listesini uygular. Kaynak
dosyayı yedekler, ayrı bir çıktı oluşturur ve sonucu yeniden açarak kontrol eder.

Program oyun, oyun lisansı veya Electronic Arts'a ait kadro paketi dağıtmaz ve
indirmez. Kullanım için FC26'ya yasal erişiminiz ve kendi uyumlu Squads dosyanız
bulunmalıdır.

## Hızlı kullanım

1. ZIP dosyasını tamamen yeni bir klasöre çıkarın.
2. `BASLAT.bat` dosyasına çift tıklayın.
3. **Mevcut Squads Dosyasını Seç** düğmesine basın.
4. Kendi dosyanızın çalışma kopyasını seçin.
5. **Güncellemeyi Oluştur** düğmesine basın.
6. Sonucu `output` klasöründe kontrol edin.

Orijinal dosyanızı ayrıca güvenli bir yerde saklayın. Program çalışma kopyasını
`output\backup` klasörüne yedeklese de tek yedeğe güvenmeyin.

Oluşturulan `SquadsFC26Sync...` dosyası, yasal FC26 kurulumu bulunan kullanıcı
tarafından oyunun kendi ayar klasörüne alınabilir. Ardından oyunda kadro yükleme
menüsünden seçilmeli ve önce yeni bir çevrimdışı kariyerde denenmelidir.

## Program ne yapar?

- Sitedeki son doğrulanmış transfer listesini indirir ve biçimini kontrol eder.
- İnternet kesilirse son sağlam önbelleği; o da yoksa paketle gelen listeyi kullanır.
- Kaynak `Squads...` dosyasını tarihli `.bak` dosyası olarak yedekler.
- Oyuncu ve takım kimlikleri güvenle eşleşen transferleri uygular.
- Belirsiz veya bulunamayan kayıtları değiştirmek yerine rapora ayırır.
- Çakışan forma numaralarını ve ilgili takım bağlantılarını düzenler.
- Oluşturulan dosyayı yeniden okuyup uygulanan transferleri doğrular.
- Ayrıntılı JSON ve Excel'de açılabilen CSV raporu üretir.

## Sınırlar ve güvenlik

- Yalnızca yasal oyun kurulumunuz ve kendi dosyanızla kullanın.
- Ultimate Team veya çevrimiçi modlarda kullanmayın.
- Devam eden kariyerin içindeki kadroyu değiştirmez.
- Her transfer kiralık/kalıcı ayrımıyla sunulmadığından sonuçları kontrol edin.
- Oyunda bulunmayan gerçek oyuncular otomatik oluşturulmaz.
- Dosya biçimi oyun güncellemeleriyle değişebilir.
- Antivirüs korumasını kalıcı olarak kapatmayın.

## Komut satırı

```powershell
python fc26_updater.py --input "C:\...\Squads..." --output-dir output
```

İnternet transfer listesini kontrol etmeden paket listesini kullanmak için:

```powershell
python fc26_updater.py --input "C:\...\Squads..." --offline
```

## Gereksinim

- Windows 10/11
- Python 3.10 veya daha yeni sürüm
- Yasal FC26 PC kurulumu ve kullanıcıya ait uyumlu Squads dosyası

## Lisans ve bağımsızlık

Uygulama MIT lisanslıdır. Dosya okuma mantığında kullanılan açık kaynak
bileşenlerin lisansları `licenses` klasöründedir.

FC26 Squad Sync; Electronic Arts veya EA SPORTS FC tarafından desteklenmez,
onaylanmaz ve bu kuruluşlarla bağlantılı değildir. İlgili markalar sahiplerine
aittir.
